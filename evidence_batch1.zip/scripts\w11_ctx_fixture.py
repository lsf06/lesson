import os, sys, shutil, datetime, json
src = r"d:\lesson\xiaolin\lesson-main (1)\lesson-main\week11_context_engine\server\app.py"
tmp = os.path.join(os.environ['TEMP'], 'w11_b1_scratch')
os.makedirs(tmp, exist_ok=True)
dbp = os.path.join(tmp, 'sensor_data.db')
if os.path.exists(dbp):
    os.remove(dbp)
shutil.copy2(src, os.path.join(tmp, 'app.py'))
sys.path.insert(0, tmp)
os.chdir(tmp)
import app as m
for fn in ('init_db', 'init_vision_db', 'init_source_states_db', 'init_user_preferences_db'):
    f = getattr(m, fn, None)
    if f:
        f()

def ts(sec_ago):
    return (datetime.datetime.now() - datetime.timedelta(seconds=sec_ago)).isoformat()

m.update_source_state('sensor', 'success', json.dumps({'ax': -0.72, 'ay': 0.52, 'az': -1.06}), observation_time=ts(20))
m.update_source_state('network', 'success', json.dumps({'online': True}), observation_time=ts(25))
m.update_source_state('camera', 'success', json.dumps({'filename': 'fixture_still.jpg', 'bytes': 4096}), observation_time=ts(22))
m.update_source_state('gps', 'success', json.dumps({'lat': 31.2304, 'lng': 121.4737}), observation_time=ts(21))

c = m.app.test_client()
mapping = {'规则推断': 'sensor', '网络连接': 'network', '位置GPS': 'gps', '摄像头': 'camera'}

def check(tag):
    ctx = c.get('/api/context').get_json()
    now_hms = datetime.datetime.now().strftime('%H:%M:%S')
    raw = ctx.get('raw_observations') or {}
    facts = (ctx.get('interaction') or {}).get('known_facts') or []
    print('=====', tag, '| now=', now_hms)
    print('derived_states =', json.dumps(ctx.get('derived_states'), ensure_ascii=False))
    ok = True
    for f in facts:
        key = None
        for p, k in mapping.items():
            if str(f.get('source', '')).startswith(p):
                key = k
                break
        o = (raw.get(key) or {}).get('observation_time')
        exp = datetime.datetime.fromisoformat(o).strftime('%H:%M:%S') if o else ''
        got = f.get('observed_at')
        good = (got == exp) and (got != now_hms)
        ok = ok and good
        print(('OK  ' if good else 'BAD '), '|', f.get('fact')[:38], '| observed_at=', got, '| 源obs=', exp, '| key=', key)
    print(tag, 'facts=', len(facts), 'ALL_OK=', ok)
    return ok, facts

o1, f1 = check('RUN1(全源20秒前)')
o2, f2 = check('RUN2(同上,重复取值稳定性)')
m.update_source_state('gps', 'success', json.dumps({'lat': 31.2304, 'lng': 121.4737}), observation_time=ts(1800))
o3, f3 = check('RUN3(gps 30分钟前→走「上次报告位置」分支)')
print('SUMMARY RUN1/RUN2/RUN3 =', o1, o2, o3)
print('PASS' if (o1 and o2 and o3) else 'FAIL')