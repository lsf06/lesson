import os, sys, shutil, json, datetime, importlib.util, socket

socket.socket.connect = lambda *a, **k: (_ for _ in ()).throw(RuntimeError('network disabled in fixture'))

ROOT = r"d:\lesson\xiaolin\lesson-main (1)\lesson-main"
WEEKS = [
    ('week1',  os.path.join(ROOT, 'week1_vps_upload', 'server', 'app.py')),
    ('week12', os.path.join(ROOT, 'week12_feedback_preferences', 'server', 'app.py')),
    ('week13', os.path.join(ROOT, 'week13_14_15_edge_inference', 'server', 'app.py')),
    ('week11', os.path.join(ROOT, 'week11_context_engine', 'server', 'app.py')),
]
for k in ('VPS_USERNAME', 'VPS_PASSWORD', 'VPS_BASE_URL'):
    os.environ[k] = ''

NOW = datetime.datetime.now()
def iso(sec):  return (NOW - datetime.timedelta(seconds=sec)).isoformat()
def secs_of_day(hms):
    h, m, s = [int(x) for x in hms.split(':')]
    return h * 3600 + m * 60 + s
def expect(sec): return secs_of_day(NOW.strftime('%H:%M:%S')) - sec

results = []
for name, path in WEEKS:
    tmp = os.path.join(os.environ['TEMP'], 'b1_oa_' + name)
    os.makedirs(tmp, exist_ok=True)
    dbp = os.path.join(tmp, 'sensor_data.db')
    if os.path.exists(dbp):
        os.remove(dbp)
    dst = os.path.join(tmp, 'app.py')
    shutil.copy2(path, dst)
    spec = importlib.util.spec_from_file_location('oa_' + name, dst)
    m = importlib.util.module_from_spec(spec)
    sys.modules['oa_' + name] = m
    spec.loader.exec_module(m)
    for fn in sorted(dir(m)):
        if fn.startswith('init_') and callable(getattr(m, fn)):
            getattr(m, fn)()
    c = m.app.test_client()
    ok = True

    def scenario(title, gps_age):
        global ok
        m.update_source_state('sensor', 'success', json.dumps({'ax': -0.72, 'ay': 0.52, 'az': -1.06}), observation_time=iso(10))
        m.update_source_state('network', 'success', 'online', observation_time=iso(9))
        m.update_source_state('camera', 'success', json.dumps({'filename': 'fixture_still.jpg'}), observation_time=iso(12))
        m.update_source_state('gps', 'success', json.dumps({'lat': 31.2304, 'lng': 121.4737}), observation_time=iso(gps_age))
        ctx = c.get('/api/context').get_json()
        facts = (ctx.get('interaction') or {}).get('known_facts') or []
        print('---', name, title)
        for f in facts:
            o = f.get('observed_at') or ''
            ok2 = False
            if '规则推断' in str(f.get('source')) or '静止' in f['fact'] or '移动' in f['fact']:
                ok2 = abs(secs_of_day(o) - expect(10)) <= 2
            elif '网络' in str(f.get('source')):
                ok2 = abs(secs_of_day(o) - expect(9)) <= 2
            elif 'GPS' in str(f.get('source')):
                ok2 = abs(secs_of_day(o) - expect(gps_age)) <= 2
            elif '摄像头' in str(f.get('source')):
                ok2 = abs(secs_of_day(o) - expect(12)) <= 2
            ok = ok and ok2
            print(('  OK  ' if ok2 else '  BAD '), f['fact'][:32], '| source=', str(f.get('source'))[:16], '| observed_at=', o)
        neq = all((f.get('observed_at') or '') != NOW.strftime('%H:%M:%S') for f in facts)
        ok = ok and neq
        print(('  OK  ' if neq else '  BAD '), 'observed_at 全都不等于 now(' + NOW.strftime('%H:%M:%S') + ')')

    scenario('A 新鲜 GPS(8s) -> 当前位置分支', 8)
    scenario('B 过期 GPS(400s) -> 上次报告位置分支', 400)

    r = c.post('/api/simulate_no_fix').get_json()
    ctx = c.get('/api/context').get_json()
    reasons = [u.get('reason') for u in ((ctx.get('interaction') or {}).get('uncertain_items') or [])]
    nf = any('无有效解' in str(x) for x in reasons)
    ds = ctx.get('derived_states') or {}
    unit = ds.get('is_moving') == '静止' and 1.0 < float(ds.get('accel_magnitude', 0)) < 2.0
    ok = ok and nf and unit
    print(('  OK  ' if (nf and unit) else '  BAD '), 'no_fix 回归 ->', json.dumps(reasons, ensure_ascii=False), '| derived ->', json.dumps(ds, ensure_ascii=False))

    if '/api/local_infer' in {r.rule for r in m.app.url_map.iter_rules()}:
        li = c.post('/api/local_infer').get_json()
        print('  INFO local_infer ->', li.get('label'))

    print('RESULT', name, 'PASS' if ok else 'FAIL')
    results.append((name, ok))

print('SUMMARY', results)
print('ALL PASS' if all(x[1] for x in results) else 'HAS FAIL')