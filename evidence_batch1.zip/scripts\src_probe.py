import sqlite3, sys, json
db, name = sys.argv[1], sys.argv[2]
c = sqlite3.connect(db)
r = c.execute("SELECT status, latest_value, previous_value, last_observation_time FROM source_states WHERE source_name=?", (name,)).fetchone()
print(json.dumps({'source': name, 'status': r[0], 'latest_value': r[1], 'previous_value': r[2], 'obs': r[3]}, ensure_ascii=False))