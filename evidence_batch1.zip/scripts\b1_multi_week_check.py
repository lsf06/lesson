import os, sys, shutil, json, sqlite3, datetime, importlib.util, socket

class Blocked(Exception):
    pass

def _no_net(*a, **k):
    raise Blocked('network disabled in fixture')

socket.socket.connect = _no_net

ROOT = r"d:\lesson\xiaolin\lesson-main (1)\lesson-main"
WEEKS = [
    ('week11', os.path.join(ROOT, 'week11_context_engine', 'server', 'app.py')),
    ('week12', os.path.join(ROOT, 'week12_feedback_preferences', 'server', 'app.py')),
    ('week1',  os.path.join(ROOT, 'week1_vps_upload', 'server', 'app.py')),
]
for k in ('VPS_USERNAME', 'VPS_PASSWORD', 'VPS_BASE_URL'):
    os.environ[k] = ''

def ts(sec):
    return (datetime.datetime.now() - datetime.timedelta(seconds=sec)).isoformat()

results = []
for name, path in WEEKS:
    tmp = os.path.join(os.environ['TEMP'], 'b1_scratch_' + name)
    os.makedirs(tmp, exist_ok=True)
    dbp = os.path.join(tmp, 'sensor_data.db')
    if os.path.exists(dbp):
        os.remove(dbp)
    dst = os.path.join(tmp, 'app.py')
    shutil.copy2(path, dst)

    spec = importlib.util.spec_from_file_location('app_' + name, dst)
    m = importlib.util.module_from_spec(spec)
    sys.modules['app_' + name] = m
    spec.loader.exec_module(m)
    for fn in sorted(dir(m)):
        if fn.startswith('init_') and callable(getattr(m, fn)):
            try:
                getattr(m, fn)()
            except Exception as e:
                print('  init warn', fn, e)

    c = m.app.test_client()
    routes = {r.rule for r in m.app.url_map.iter_rules()}
    print('=====', name, '| routes:', '/api/local_infer' in routes, '/api/context' in routes)
    ok = True

    m.update_source_state('sensor', 'success', json.dumps({'ax': -0.72, 'ay': 0.52, 'az': -1.06}), observation_time=ts(10))
    m.update_source_state('camera', 'success', json.dumps({'filename': 'fixture_still.jpg'}), observation_time=ts(12))
    m.update_source_state('network', 'success', 'online', observation_time=ts(9))

    if '/api/local_infer' in routes:
        r = c.post('/api/local_infer').get_json()
        good = r.get('label') == '环境正常'
        ok = ok and good
        print(('OK  ' if good else 'BAD '), 'local_infer ->', r.get('label'), '|', r.get('detail'))

    m.update_source_state('gps', 'success', json.dumps({'lat': 31.2304, 'lng': 121.4737}), observation_time=ts(8))
    r = c.post('/api/simulate_no_fix').get_json()
    print('     simulate_no_fix ->', json.dumps(r, ensure_ascii=False))
    row = sqlite3.connect(dbp).execute("SELECT status, latest_value, previous_value FROM source_states WHERE source_name='gps'").fetchone()
    nofix_ok = (row[0] == 'no_fix') and (row[2] is not None) and ('31.2304' in str(row[2]))
    ok = ok and nofix_ok
    print(('OK  ' if nofix_ok else 'BAD '), 'gps 行 -> status=', row[0], '| previous_value 保留旧坐标=', nofix_ok)

    if '/api/context' in routes:
        ctx = c.get('/api/context').get_json()
        ds = ctx.get('derived_states') or {}
        inter = ctx.get('interaction') or {}
        facts = inter.get('known_facts') or []
        unc = inter.get('uncertain_items') or []
        now_hms = datetime.datetime.now().strftime('%H:%M:%S')
        mv_ok = ds.get('is_moving') == '静止' and 1.0 < float(ds.get('accel_magnitude', 0)) < 2.0
        ok = ok and mv_ok
        print(('OK  ' if mv_ok else 'BAD '), 'context derived ->', json.dumps(ds, ensure_ascii=False))
        reasons = [u.get('reason') for u in unc]
        nf_ok = any('无有效解' in str(x) for x in reasons)
        ok = ok and nf_ok
        print(('OK  ' if nf_ok else 'BAD '), 'context uncertain ->', json.dumps(reasons, ensure_ascii=False))
        obs_ok = True
        for f in facts:
            o = f.get('observed_at')
            if o == now_hms:
                obs_ok = False
            print('     fact:', f.get('fact')[:34], '| observed_at=', o, '| source=', f.get('source')[:18])
        ok = ok and obs_ok
        print(('OK  ' if obs_ok else 'BAD '), 'none of observed_at equals now(' + now_hms + ')')

    print('RESULT', name, 'PASS' if ok else 'FAIL')
    results.append((name, ok))

print('SUMMARY', results)
print('ALL PASS' if all(r[1] for r in results) else 'HAS FAIL')