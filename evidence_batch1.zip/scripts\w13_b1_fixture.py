import os, sys, shutil, datetime, json
src = r"d:\lesson\xiaolin\lesson-main (1)\lesson-main\week13_14_15_edge_inference\server\app.py"
tmp = os.path.join(os.environ['TEMP'], 'w13_b1_scratch')
os.makedirs(tmp, exist_ok=True)
dbp = os.path.join(tmp, 'sensor_data.db')
if os.path.exists(dbp):
    os.remove(dbp)
shutil.copy2(src, os.path.join(tmp, 'app.py'))
sys.path.insert(0, tmp)
os.chdir(tmp)
import app as m
m.init_db(); m.init_vision_db(); m.init_source_states_db(); m.init_user_preferences_db()
now = datetime.datetime.now().isoformat()
m.update_source_state('camera', 'success', json.dumps({'filename': 'fixture_static.jpg'}), observation_time=now)
c = m.app.test_client()
def infer(ax, ay, az, tag):
    m.update_source_state('sensor', 'success', json.dumps({'ax': ax, 'ay': ay, 'az': az}),
                          observation_time=datetime.datetime.now().isoformat())
    r = c.post('/api/local_infer').get_json()
    mag = (ax*ax + ay*ay + az*az) ** 0.5
    print(tag, '| ax,ay,az=', (ax, ay, az), '| |a|=', round(mag, 3), '->', r['label'], '| score=', r['score'], '| detail=', r['detail'])
    return r
r1 = infer(-0.72, 0.32, -1.04, 'STATIC(实测静止向量)')
r2 = infer(0.50, 0.50, 1.50,  'MOTION(合成运动向量)')
print('ASSERT static_is_normal =', r1['label'] == '环境正常')
print('ASSERT motion_is_moving =', r2['label'] == '可能在移动')
print('PASS' if (r1['label'] == '环境正常' and r2['label'] == '可能在移动') else 'FAIL')